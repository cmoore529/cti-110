# CTI 110
# P1T1
# Chase Moore
#10/30

# say hello
print("Hello World")

print("Goodbye!")


